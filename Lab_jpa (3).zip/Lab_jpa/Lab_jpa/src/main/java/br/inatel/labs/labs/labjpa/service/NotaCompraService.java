package br.inatel.labs.labs.labjpa.service;

import br.inatel.labs.labs.labjpa.entity.NotaCompra;
import br.inatel.labs.labs.labjpa.entity.NotaCompraItem;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class NotaCompraService {

    @PersistenceContext
    private EntityManager em;

    public NotaCompra salvarNotaCompra(NotaCompra  nc){
        nc=em.merge(nc);
        return nc;
    }

    public NotaCompra buscarNotaCompraPeloId(Long id){
        NotaCompra nc=em.find(NotaCompra.class,id);
        return nc;
    }

    public NotaCompra buscarNotaCompraPeloIdcComListaItem(Long id){
        NotaCompra nc=em.find(NotaCompra.class,id);
        nc.getListNotacompraItem().size();
        return nc;
    }

    public List<NotaCompra> listaNotaCompra(){
        List<NotaCompra> notas=em.createQuery("select n from NotaCompra n",NotaCompra.class)
                .getResultList();
        return notas;
    }

    public NotaCompraItem salvarNotaCompraItemPeloId(NotaCompraItem item){
        return em.merge(item);
    }

    public NotaCompraItem buscarNotaCompraItemPeloId(Long id){
        return em.find(NotaCompraItem.class,id);
    }

    public List<NotaCompraItem>ListaNotaCompraItem(){
        return em.createQuery("select i from NotaCompraItem i",NotaCompraItem.class)
                .getResultList();
    }

}
