package br.inatel.labs.labs.labjpa.service;

import br.inatel.labs.labs.labjpa.entity.Fornecedor;
import br.inatel.labs.labs.labjpa.entity.Produto;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class FornecedorService {

    @PersistenceContext
    private EntityManager em;
    public Fornecedor salvar(Fornecedor f){
        f=em.merge(f);
        return f;
    }
    public Fornecedor buscarPeloId(Long id){
        Fornecedor fornecedor=em.find(Fornecedor.class,id);
        return fornecedor;
    }
    public List<Fornecedor> listar(){
        List<Fornecedor>listaFornecedor=em.createQuery("select f from Fornecedor f",Fornecedor.class)
                .getResultList();
        return listaFornecedor;
    }
    public void remover(Fornecedor f){
        f=em.merge(f);
        em.remove(f);
    }
}
