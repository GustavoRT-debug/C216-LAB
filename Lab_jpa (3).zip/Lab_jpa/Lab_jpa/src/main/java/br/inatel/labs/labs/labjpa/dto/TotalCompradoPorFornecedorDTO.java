package br.inatel.labs.labs.labjpa.dto;

import java.math.BigDecimal;

public class TotalCompradoPorFornecedorDTO {

    private final String fornecedorRazaoSocial;
    private final BigDecimal totalComprado;

    public TotalCompradoPorFornecedorDTO(String fRazaoSocial, BigDecimal total) {
        this.fornecedorRazaoSocial = fRazaoSocial;
        this.totalComprado = total;
    }

    public String getFornecedorRazaoSocial() {
        return fornecedorRazaoSocial;
    }

    public BigDecimal getTotalComprado() {
        return totalComprado;
    }

	@Override
	public String toString() {
		return "TotalCompradorPorFornecedorDTO [fornecedorRazaoSocial=" + fornecedorRazaoSocial + ", totalComprado="
				+ totalComprado + "]";
	}
    
    

}
