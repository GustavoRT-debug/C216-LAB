DELETE FROM Produto;

INSERT INTO Produto (id, descricao) VALUES (1, 'Serrote');
INSERT INTO Produto (id, descricao) VALUES (2, 'Martelo');
INSERT INTO Produto (id, descricao) VALUES (3, 'Prego');
