package br.inatel.labs.labs.labjpa.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import br.inatel.labs.labs.labjpa.service.ProdutoService;
import org.junit.jupiter.api.Test;

import br.inatel.labs.labs.labjpa.entity.Produto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
public class ProdutoServiceTest {

	  @Autowired
	  private ProdutoService service;

	  @Test
	  void dadoIdValido_quandoInvocaBuscarPeloId_entaoProdutoRetornadoEhValido() {
	    Long idValido = 1L;

	    Produto produtoEncontrado = service.buscarPeloId( idValido );

	    assertFalse( produtoEncontrado == null );
	    assertFalse( produtoEncontrado.getDescricao().isBlank() );

	    assertEquals( idValido, produtoEncontrado.getId() );
	  }
	}

