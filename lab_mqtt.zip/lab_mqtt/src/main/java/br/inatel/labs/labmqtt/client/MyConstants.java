package br.inatel.labs.labmqtt.client;

public interface MyConstants {
	String URI_BROKER = "tcp://localhost:1883";
	String TOPIC_1 = "meu_topico";
}
